BigInteger.prototype.lowVal = function() {
  return this._d[0] || 0;
};