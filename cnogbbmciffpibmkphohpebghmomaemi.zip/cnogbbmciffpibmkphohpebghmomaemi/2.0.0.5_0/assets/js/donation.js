// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

document.addEventListener('DOMContentLoaded', function() {
  // Buttons to add click
  const showCalendar = document.getElementById('showCalendar');
  const showMoreWallet = document.getElementById('showMoreWallet');
  const showMoreWalletMonthly = document.getElementById('showMoreWalletMonthly');
  const showLessWallet = document.getElementById('showLessWallet');
  const showLessWalletMonthly = document.getElementById('showLessWalletMonthly');
  const buttonCancel = document.getElementById('buttonCancel');
  const buttonCancelMonthly = document.getElementById('buttonCancelMonthly');
  const walletItem = document.getElementById('walletItem');
  const buttonStandBy = document.getElementById('buttonStandBy');
  // button flip
  const buttonFlip = document.getElementById('buttonFlip');
  const tabMonthly = document.getElementById('tabMonthly');
  let instanceDonationError;
  let instanceTransactionSent;
  buttonCancel.addEventListener('click', function(){
    window.location.href = 'airtime.html'
  });
  buttonCancelMonthly.addEventListener('click', function(){
    window.location.href = 'airtime.html'
  });

  walletItem.addEventListener('click', function() {
    window.open(window.location.origin + '/wallet/index.html#!/overview');
  });

  if ( tabMonthly != null ){
    tabMonthly.addEventListener('mouseenter', function(e){
        document.getElementById('spanComingSoon').classList.add('tooltiptextTabsVisible');
    });

    tabMonthly.addEventListener('mouseleave', function(e){
        document.getElementById('spanComingSoon').classList.remove('tooltiptextTabsVisible');
    });
  }
  
  //load title on publisher view
  
  

  let instanceCalendar = mobiscroll.calendar('#selectDate', {
    showOnTap: false,
    showOnFocus: false,
    dateFormat: 'yyyy/mm/dd',
    onInit: function (event, inst) {
        inst.setVal(new Date(), true);
    }
});

  showCalendar.addEventListener('click', function(){
    //showCalendar
    instanceCalendar.show();
  });

  
  // initialize mobiscroll calendar
  mobiscroll.settings = {
      theme: 'mobiscroll',
      lang: 'de'
  };

  mobiscroll.nav('#tabsDonate', {
      theme: 'ios',
      type: 'tab',
      cssClass: 'divTabsPublisher',
      onItemTap: function (event, inst) {
        //   document.querySelector('.md-apps-tab-sel').classList.remove('md-apps-tab-sel');
        //   document.querySelector('#apps-tab-' + event.target.getAttribute('data-tab')).classList.add('md-apps-tab-sel');
         
          if (event.target.getAttribute('data-tab') == 'monthly'){
        
          }
      }
  });

  
  
  let walletAddress = localStorage.getItem('walletToDonate'); //'bxdJo3NJrnVS3Vah2h7B3JKNes5Pss5yLjmLoto2trPCgfuLR6Kxfea9qijdBtxh1nMLENCUJsdZC6AUM698Zi3x2ZDxE2kV3';
  
  document.getElementById('spanWalletAddress').innerHTML = walletAddress;
  document.getElementById('spanWalletAddressMonthly').innerHTML = walletAddress;

  document.getElementById('spanPaymentId').innerText = randHex(64); //'000'; // preparing function for when we use the payment id random_string(64) or random_string(16);
//   document.getElementById('spanAmount').innerText += i18next.t('calculating');
//   showHideButtonLoader('buttonConfirm', 'showLoader');
  //  random hex string generator
function randHex(len) {
    var maxlen = 8,
        min = Math.pow(16,Math.min(len,maxlen)-1),
        max = Math.pow(16,Math.min(len,maxlen)) - 1,
        n   = Math.floor( Math.random() * (max-min+1) ) + min,
        r   = n.toString(16);
    while ( r.length < len ) {
       r = r + randHex( len - maxlen );
    }
    return r;
  };
  
 // Copy TX data
const allCopyTx=document.querySelectorAll(".txCopy")
for(let i=0;i<3;i++){
    allCopyTx[i].addEventListener("click", (e) => {
        e.preventDefault();
        e.stopPropagation();
        const url =e.path[1].parentElement.querySelector(".inputContent").innerHTML;
        const selBox = document.createElement('textarea');
        selBox.style.position = 'fixed';
        selBox.style.left = '0';
        selBox.style.top = '0';
        selBox.style.opacity = '0';
        selBox.value = url;
        document.body.appendChild(selBox);
        selBox.focus();
        selBox.select();
        document.execCommand('copy');
        document.body.removeChild(selBox);
    })
}


  //Donation Wallet functions
  firebase.auth().onAuthStateChanged(async function(user) 
  {
        if (user) {
            let token = await firebase.auth().currentUser.getIdToken();
            let wallets = await WalletHelpers.getWalletsInfo(token);
            var onlinewallet = wallets.onlinewallet;
            let public_address = onlinewallet.public_addr;

            let pub_keys = {
                view: onlinewallet.view.pub,
                spend: onlinewallet.spend.pub
            }

            let sec_keys = {
                view: onlinewallet.view.sec,
                spend: onlinewallet.spend.sec
            }
            
            async function new_send_coins(Address, Amount, payId)
            {   
                // Address = public_address;
                showHideButtonLoader('buttonConfirm', 'showLoader');
                let parsed_amount;
                try {
                    parsed_amount = mymonero_core_js.monero_amount_format_utils.parseMoney(Amount);
                } catch (e) {
                    showDonationError("Please enter a valid amount");
                    return;
                }
                var params = {
                    is_sweeping: false, 
                    payment_id_string: payId, // passed in
                    sending_amount: parsed_amount.toString(), // sending amount
                    from_address_string: public_address,
                    sec_viewKey_string: sec_keys.view,
                    sec_spendKey_string: sec_keys.spend,
                    pub_spendKey_string: pub_keys.spend,
                    to_address_string: Address,
                    priority: 1,
                    unlock_time: 0, // unlock_time 
                    nettype: 0,
                    get_unspent_outs_fn: function(req_params, cb)
                    {
                        WalletHelpers.getUnspentOuts(req_params, function(err_msg, res){
                            cb(err_msg, res);
                        })
                    },
                    get_random_outs_fn: function(req_params, cb)
                    {
                        WalletHelpers.getRandomOuts(req_params, function(err_msg, res)
                        {
                            cb(err_msg, res);
                        });
                    },
                    submit_raw_tx_fn: function(req_params, cb)
                    {
                        WalletHelpers.submitRawTx(req_params, function(err_msg, res)
                        {
                            cb(err_msg, res);
                        });
                    },
                    status_update_fn: function(params)
                    {
                    },
                    error_fn: function(params)
                    {
                        showDonationError(params.err_msg);
                        return;
                    },
                    success_fn: async function(params)
                    {
                        const sent_tx = {
                            userSocialId: localStorage.getItem('userSocialId'),
                            userPlatorm: localStorage.getItem('userPlatform'),
                            username: localStorage.getItem('userToDonate'),
                            address: Address,
                            amount: Amount,
                            paymentId: params.final_payment_id,
                            tx_hash: params.tx_hash,
                            tx_key: params.tx_prvkey,
                            tx_fee: params.used_fee
                        };
                        
                        const data = {
                            suffix: 'donations',
                            type: 0,
                            data: sent_tx
                        };
                        showTransactionSent(sent_tx);

                        if (localStorage.getItem('videoId') != undefined ){
                            var videoId = localStorage.getItem('videoId');
                        }else{
                            var videoId = '';
                        }
                        var userWillGetNotification = false;
                        var domainNotification = document.getElementById('headerTitle').getAttribute('data-platform');
                        switch (domainNotification){
                            case 'https://www.youtube.com':
                            case 'youtube.com':
                            case 'youtube':
                            case 'twitter.com/':
                            case 'twitter.com':
                            case 'twitter':
                            case 'twitch':
                            case 'twitch.tv':
                            userWillGetNotification = true;
                            break;
                        }
                        if (userWillGetNotification){
                            chrome.runtime.sendMessage({message: "ApiSocial", Domain: domainNotification, User: document.getElementById('headerTitle').getAttribute('data-userinfo'), videoId: videoId, amount: localStorage.getItem('ammontToDonate')}, function(response){
                                console.log('Response API SOCIAL ===> ', response);
                            });
                        }
                        await WalletHelpers.addHistory(token, data);
                        showHideButtonLoader('buttonConfirm', 'hideLoader');
                    },
                }

                let login_success = await WalletHelpers.walletLogin(public_address, sec_keys.view);
                if(!login_success)
                {
                    showDonationError('Something went wrong. Please try again');
                    return;
                }

                let blockchain_height = await WalletHelpers.getBlockchainHeight(public_address, sec_keys.view);
                if(!blockchain_height)
                {
                    showDonationError('Failed to retrieve blockchain height please try again');
                    return;
                }
                
                let coreBridge_instance = await mymonero_core_js.monero_utils_promise;
                coreBridge_instance.set_current_blockchain_height(blockchain_height);
                coreBridge_instance.async__send_funds(params);
            }
            // document.getElementById('donationAmountTubeIcon').classList.remove('displayNone');
            document.getElementById('spanAmount').innerHTML = `${localStorage.getItem('ammontToDonate')} <i class="icon-font-tube tubeFont10"></i> (+ ` + i18next.t('fee') + ')';
            // showHideButtonLoader('buttonConfirm', 'hideLoader');

            document.getElementById('buttonConfirm').addEventListener('click', function(e)
            {
                getUserSecurity(function(response)
                {
                    if(response == 'userHasSecurity')
                    {
                        document.getElementById("donate-2fa-modal").style.display = 'block';
                    }
                    else
                    {
                        
                        new_send_coins(walletAddress, localStorage.getItem('ammontToDonate'), document.getElementById('spanPaymentId').innerText);
                    }
                });
            });

            document.getElementById('donate-verify2FASecret').placeholder = i18next.t('2FACode');

            document.getElementById('donate-verify2FASecret').addEventListener('focus', function(e){
                removeErrors(this);
                document.getElementById('donate-verify2FASecret').placeholder = '';
                document.getElementById('labelConfirmDonate').style.animation = "labelAppear 0.5s ease-out forwards";
            });

            document.getElementById('donate-verify2FASecret').addEventListener('blur', function(e){
                if ( this.value == '' ){
                    document.getElementById('donate-verify2FASecret').placeholder = i18next.t('2FACode');
                    document.getElementById('labelConfirmDonate').style.animation = "labelDisappear 0.5s ease-out forwards";
                }
                
            });

            document.getElementById('donate-verifyBtn').addEventListener('click', function(e)
            {
                e.preventDefault();
                var secret = document.getElementById('donate-verify2FASecret').value;
                verify2FASecret(secret, function(response)
                {
                    if(response == 'SecurityEnable'){
                        document.getElementById("donate-2fa-modal").style.display = 'none';
                        new_send_coins(walletAddress, localStorage.getItem('ammontToDonate'), document.getElementById('spanPaymentId').innerText);
                    }
                    else
                    {
                        const error = [i18next.t(the2FANotCorrect)];
                        const inputWithError = ['donate-verify2FASecret'];
                        setErrors(error, inputWithError);
                    }
                });
            });

            function getUserSecurity(callback)
            {
                firebase.auth().currentUser.getIdToken().then(function(token) 
                {
                    const url = functionBaseURL + '/app/getUserSecurity';
                    sendGetRequest(url, token, function(user, response){
                        try{
                        if(callback)
                            callback(response);
                        }
                        catch(ex)
                        {
                            console.log(ex);
                        console.log(response);
                        }
                    });
                });
            }

            function verify2FASecret(secret, callback)
            {
                if ( secret != '' ){
                    firebase.auth().currentUser.getIdToken().then(function(token){
                        const url = 'https://us-central1-bittube-airtime-extension.cloudfunctions.net/app/verifySecret?userToken='+secret+'&action=verifySecret';
                        sendGetRequest(url, token, function(user, response){
                            try{
                            if(callback)
                                callback(response);
                            }
                            catch(ex)
                            {
                                console.log(response);
                            }
                        });
                    });
                }else{
                    const error = [i18next.t('fieldRequired')];
                    const inputWithError = ['donate-verify2FASecret'];
                    setErrors(error, inputWithError);
                }
                
            }

            function showTransactionSent(data_transaction){
                instanceTransactionSent = mobiscroll.popup('#transactionSent', {
                    display: 'center',
                    closeOnOverlayTap : false,
                    cssClass: 'popUpResendEmail transactionModal',
                    buttons: [
                        {
                            text: i18next.t('close'),
                            cssClass: 'buttonModdal',
                            handler: function (event, inst) {
                                inst.hide();
                                window.location.href = '/airtime.html';
                            }
                        }
                    ],
                    onBeforeShow: function (ev, inst) {

                        document.getElementById('userDonated').innerText = data_transaction.username;
                        document.getElementById('amountDonated').innerHTML =  data_transaction.amount + ' <i class="icon-font-tube tubeFont"></i> / <label id="fiatValueDonated"></label> <br><label class="modalDate">' + new Date(Date.now()).toUTCString().split('GMT')[0];
                        fetchTUBEValue(localStorage.getItem('currencySelected')).then(function(responseFetch){
                        if (responseFetch != undefined){
                            let currencySymb;
                            switch (responseFetch.currency){
                              case 'USD':
                                currencySymb = '&dollar;'
                              break;
                              case 'AUD':
                                currencySymb = 'A&dollar;'
                              break;
                              case 'GBP':
                                currencySymb = '&pound;'
                              break;
                              case 'NZD':
                                currencySymb = 'N&dollar;'
                              break;
                              case 'EUR':
                                currencySymb = '&euro;'
                              break;
                            }
                            document.getElementById('fiatValueDonated').innerHTML = ( new Number(data_transaction.amount) * responseFetch.value).toFixed(2) + ' ' + currencySymb
                        }
                        });
                        document.getElementById('paymentIdSpan').innerText = data_transaction.paymentId;
                        document.getElementById('addrUserWallet').innerText = data_transaction.address;
                        document.getElementById('tx_hash').innerHTML = '<a target="blank" href=https://explorer.bit.tube/tx/' + data_transaction.tx_hash + '>' + data_transaction.tx_hash + '</a>';

                        new QRCode(document.getElementById('qrDonation'), {
                            text: "https://explorer.bit.tube/tx/" + data_transaction.tx_hash,
                            width: 75,
                            height: 75,
                            colorDark : "#000000",
                            colorLight : "#ffffff",
                            correctLevel : QRCode.CorrectLevel.L
                        });

                        const labelQR = document.createElement('label');
                        labelQR.className = 'labelQR';
                        labelQR.innerHTML = i18next.t('bittube') + '<br>' + i18next.t('transactionExplorer'); //'BitTube <br> transaction explorer';
                        document.getElementById('qrDonation').appendChild(labelQR);
                    }
                });
                
                instanceTransactionSent.show();
            }


            function showDonationError(error){
                instanceDonationError = mobiscroll.popup('#transactionError', {
                    display: 'center',
                    closeOnOverlayTap : false,
                    cssClass: 'popUpResendEmail transactionModal',
                    buttons: [
                        {
                            text: i18next.t('close'),
                            cssClass: 'buttonModdal',
                            handler: function (event, inst) {
                                window.location.href = '/airtime.html';
                                inst.hide();
                            }
                        }
                    ],
                    onBeforeShow: function (ev, inst) {
                        document.getElementById('donationError').innerText = error;
                        
                    }
                });
                
                instanceDonationError.show();
            }

        }
    });

});

