// Copyright 2018 The Chromium Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

'use strict';

document.addEventListener('DOMContentLoaded', function() {
    //  PLACEHOLDERS FORM SEARCH
    if(document.getElementById('searchHistoryForm') != null ){
        const allLabels = document.querySelectorAll(".dynamicLabel");
        const allInput = document.querySelectorAll(".loginInput");
        for(let i=0;i<allLabels.length;i++){
            switch(i){
                case 0:
                setTimeout(function(e){
                    allInput[i].placeholder = i18next.t('searchMinAmount');
                }, 650)
                
                break;
                case 1:
                setTimeout(function(e){
                    allInput[i].placeholder = i18next.t('searchMaxAmount');
                }, 650)
                
                break;
                case 2:
                setTimeout(function(e){
                    allInput[i].placeholder = i18next.t('searchDateFrom');
                }, 650)
                
                break;
                case 3:
                setTimeout(function(e){
                    allInput[i].placeholder = i18next.t('searchDateTo');
                }, 650)
                
                break;
            }
            allInput[i].addEventListener("focus",() => {
                allInput[i].placeholder=""
                allLabels[i].style.animation="labelAppear 0.5s ease-out forwards"
            })
            
        }


        const buttonsType = document.querySelectorAll('.buttonsSearchType');
        for(let i=0;i<buttonsType.length;i++){
            
            buttonsType[i].addEventListener("click",function(e){
               e.preventDefault();
               e.stopPropagation();
               setButtonHistoryActive(this);
               document.getElementById('searchHistory').setAttribute('data-historyType', this.id)
            })
            
        }

        mobiscroll.calendar('#dateFrom', {
            theme: 'mobiscroll',
            dateFormat: 'dd/mm/yy'
        });

        
        mobiscroll.calendar('#dateTo', {
            theme: 'mobiscroll',
            dateFormat: 'dd/mm/yy'
        });


        const dateFrom = document.getElementById('dateFrom');
        dateFrom.addEventListener('click', function(e){
            removeErrors(this);
        })

        const dateTo = document.getElementById('dateTo');
        dateTo.addEventListener('click', function(e){
            removeErrors(this);
        })
        
        const searchHistory = document.getElementById('searchHistory');
        searchHistory.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            if (checkDates()){
                showHideButtonLoader('searchHistory', 'showLoader');
                const type = this.getAttribute('data-historyType');

                let collection;
                switch (type){
                    case 'searchAll':
                        collection = 'all';
                    break;
                    case 'searchEarnings':
                        collection = 'earnings';
                    break;
                    case 'searchExpenses':
                        collection = 'expenses';
                    break;
                }

                getUSerHistory(collection, 0, 'search');
            }
        });

        const newSearch = document.getElementById('newSearch');
        newSearch.addEventListener('click', function(e){
            newSearchF();
        });

        const newSearchNoResult = document.getElementById('newSearchNoResult');
        if (newSearchNoResult != null){
            newSearchNoResult.addEventListener('click', function(e){
                hideNoResultsSearch();
                newSearchF();
            })
        }
        
    }
     // History Tabs
     if (document.getElementById('tabsHistory') != null ){
        mobiscroll.nav('#tabsHistory', {
          theme: 'ios',
          type: 'tab',
          cssClass: 'divTabsPublisher',
          onItemTap: function (event, inst) {
            document.querySelector('.md-apps-tab-sel').classList.remove('md-apps-tab-sel');
            document.querySelector('#apps-tab-' + event.target.getAttribute('data-tab')).classList.add('md-apps-tab-sel');

            //ONE TAB JS CODE
            
            //LEGACY MULTI-TABS
            if ( event.target.getAttribute('data-tab') == 'expenses' ){
                cleanTabOnClick('loaderPurchases', 'noPurchasesDiv', 'dataPurchase', 'ulPurchases');
                hideNoResultsSearch();
                newSearchF();
                document.getElementById('loadMorePurchases').setAttribute('data-from', '0');
                getUSerHistory('expenses', 0);
            } else if ( event.target.getAttribute('data-tab') == 'earnings' ){
                cleanTabOnClick('loaderEarnings', 'noEarningsDiv', 'dataEarnings', 'ulEarnings');
                hideNoResultsSearch();
                newSearchF();
                document.getElementById('loadMoreEarnings').setAttribute('data-from', '0');
                getUSerHistory('earnings', 0);
            } else if ( event.target.getAttribute('data-tab') == 'all' ){
                hideNoResultsSearch();
                newSearchF();
                cleanTabOnClick('loaderDonations', 'noDonationsDiv', 'dataDonations', 'ulDonations');
                document.getElementById('loadMoreDonations').removeAttribute('disabled');
                document.getElementById('loadMoreDonations').setAttribute('data-from', '0');
                getUSerHistory('all', 0);
            } else if ( event.target.getAttribute('data-tab') == 'search' ){
                document.getElementById('loaderSearch').classList.remove('displayNone');
                document.getElementById('searchHistoryForm').classList.add('fadeOut');
                document.getElementById('searchHistoryForm').classList.remove('fadeIn');
                document.getElementById('ulSearch').innerHTML = '';
                document.getElementById('minAmountToSearch').value = '';
                document.getElementById('maxAmountToSearch').value = '';
                document.getElementById('dateFrom').value = '';
                document.getElementById('dateTo').value = '';
                setTimeout(function(e){
                    document.getElementById('loaderSearch').classList.add('displayNone');
                    document.getElementById('searchHistoryForm').classList.remove('fadeOut');
                    document.getElementById('searchHistoryForm').classList.add('fadeIn');
                }, 1000);
            }
        }
        });
    }
    
    const loadMorePurchases = document.getElementById('loadMorePurchases');
    const loadMoreEarnings = document.getElementById('loadMoreEarnings');
    const loadMoreDonations = document.getElementById('loadMoreDonations');
    
    // button load more purchases;
    if (loadMorePurchases != null){
        loadMorePurchases.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            showHideButtonLoader('loadMorePurchases', 'showLoader');
            const query_from = this.getAttribute('data-from');
            getUSerHistory('expenses', query_from);
        })

    }

    // Buttom load more earnings;
    if (loadMoreEarnings != null){
        loadMoreEarnings.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            
            showHideButtonLoader('loadMoreEarnings', 'showLoader'); 
            const query_from = this.getAttribute('data-from');
            getUSerHistory('earnings', query_from);
        })

    }

    // Buttom load more donations;
    if (loadMoreDonations != null){
        loadMoreDonations.addEventListener('click', function(e){
            e.preventDefault();
            e.stopPropagation();
            showHideButtonLoader('loadMoreDonations', 'showLoader');
            const query_from = this.getAttribute('data-from');
            getUSerHistory('all', query_from);
        })

    }

    function cleanTabOnClick(loader, div, divData, ulData){
        document.getElementById(loader).classList.remove('displayNone');
        document.getElementById(div).classList.add('displayNone');
        document.getElementById(divData).classList.add('displayNone');
        document.getElementById(ulData).innerHTML = '';
    }

    function setButtonHistoryActive(element){
        const buttonsType = document.querySelectorAll('.buttonsSearchType');
        for(let i=0;i<buttonsType.length;i++){
            buttonsType[i].classList.remove('selected');
        }
        element.classList.add('selected');

    }

    function checkDates(){
        const dateFrom = document.getElementById('dateFrom');
        const dateTo = document.getElementById('dateTo');
        let errors;
        let elementsWithErrors;
        if (dateFrom.value === '' && dateTo.value === ''){
            errors = [i18next.t('fieldRequired'), i18next.t('fieldRequired')];
            elementsWithErrors = ['dateFrom', 'dateTo'];
            setErrors(errors, elementsWithErrors);
            return false;
        }else if (dateFrom.value === ''){
            errors = [i18next.t('fieldRequired')];
            elementsWithErrors = ['dateFrom'];
            setErrors(errors, elementsWithErrors);
            return false;
        }else if (dateTo.value === ''){
            errors = [i18next.t('fieldRequired')];
            elementsWithErrors = ['dateTo'];
            setErrors(errors, elementsWithErrors);
            return false;
        }else if(dateFrom.value !== '' && dateTo.value !== ''){
            return true;
        }
    }

    const hideNoResultsSearch = function(){
        document.getElementById('searchHistoryForm').classList.remove('displayNone');
        document.getElementById('noSearchResults').classList.add('displayNone');
    }
    const newSearchF = function(){
        document.getElementById('dataSearch').classList.remove('fadeIn');
        document.getElementById('dataSearch').classList.add('fadeOut');
        document.getElementById('searchHistoryForm').classList.remove('fadeOut');
        document.getElementById('ulSearch').innerHTML = '';

            const allLabels = document.querySelectorAll(".dynamicLabel");
            const allInput = document.querySelectorAll(".loginInput");
            for(let i=0;i<allLabels.length;i++){
                allInput[i].value = "";
                switch(i){
                    case 0:
                    allInput[i].placeholder="Min Amount";
                    break;
                    case 1:
                    allInput[i].placeholder="Max Amount";
                    break;
                    case 2:
                    allInput[i].placeholder="Date from";
                    break;
                    case 3:
                    allInput[i].placeholder="Date to";
                    break;
                }

                allLabels[i].style.animation="labelDisappear 0.5s ease-out forwards";
            }
    }

    const closeHistory = document.getElementById('closeHistory');
    if ( closeHistory != undefined ){
        closeHistory.addEventListener('click', function(e){
            window.location.href = '/account.html';
        })
    }
});