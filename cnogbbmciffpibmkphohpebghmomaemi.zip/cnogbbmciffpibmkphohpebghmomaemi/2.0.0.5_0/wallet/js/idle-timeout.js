
var inactivity_accepted_button = document.getElementById('inactivity_accepted_button');
if(inactivity_accepted_button != null)
{
    inactivity_accepted_button.addEventListener('click',function(){
        window.close();
    })
}


var logoutButton = document.getElementById('logoutButton');
if (logoutButton != null){
    logoutButton.addEventListener('click', function(){
        window.close();
    });
}
