thinwalletDirectives.directive('transaction', function () {
    return {
        restrict: 'E',
        templateUrl:"js/directives/transaction.html",
        replace: true,
    };
});
